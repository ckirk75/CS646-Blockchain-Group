// app.js
console.log("app.js loaded ");

// pull ethers from global
const ethers = window.ethers;

console.log("window.ethers = ", window.ethers);


if (!ethers) {
  console.error("Ethers is not available on window. Check the CDN script tag.");
}


const { useState, useEffect } = React;


// Address of deployed GameOwnership contract on Coston
const GAME_OWNERSHIP_ADDRESS = "0xE6E3667ac2F0C264cfb507D5a3A01242B440d3E2";

// ABI: only functions & event we need
const GAME_OWNERSHIP_ABI = [
  "function buyGame(uint256 gameId) payable returns (uint256 tokenId)",
  "function games(uint256 gameId) view returns (uint256 priceWei, string tokenURI, bool active)",
  "function refundToken(uint256 tokenId) external",
  "event GamePurchased(uint256 indexed gameId, uint256 indexed tokenId, address indexed buyer, uint256 pricePaid)",
  "event GameRefunded(uint256 indexed gameId, uint256 indexed tokenId, address indexed buyer, uint256 refundAmount)"
];


// Simple hex-wei → human-readable CFLR string
// Convert native CFLR hex-wei → human-readable string
function formatCflrFromHex(hex) {
  try {
    if (!hex) return null;

    const wei = parseInt(hex, 16);            // "0x5..." -> number
    if (Number.isNaN(wei)) return null;

    const ether = wei / 1e18;                 // CFLR uses 18 decimals
    return ether.toFixed(4);                  // e.g. "99.9995"
  } catch (e) {
    console.error("Failed to format CFLR balance:", e, hex);
    return null;
  }
}

// Encode balanceOf(address) call data for ERC-20
function encodeBalanceOfData(address) {
  // function selector for balanceOf(address): keccak256("balanceOf(address)") → 0x70a08231
  const selector = "70a08231";

  // address without 0x, left-padded to 64 hex chars
  const addr = address.toLowerCase().replace(/^0x/, "");
  const padded = addr.padStart(64, "0");

  return "0x" + selector + padded;
}

// Call the ERC-20 token and return human-readable CFLR balance as string
async function fetchCflrTokenBalance(walletAddress) {
  if (!walletAddress || !window.ethereum || !CFLR_TOKEN_ADDRESS) {
    return null;
  }

  const data = encodeBalanceOfData(walletAddress);

  const resultHex = await window.ethereum.request({
    method: "eth_call",
    params: [
      {
        to: CFLR_TOKEN_ADDRESS,
        data,
      },
      "latest",
    ],
  });

  console.log("CFLR token raw balance hex:", resultHex);
  const formatted = formatCflrFromHex(resultHex);
  console.log("CFLR token formatted:", formatted);

  return formatted;
}


// ---------------- NAVBAR ----------------
function NavBar({ user, cart, currentPage, goToPage, onSignOut }) {
  return (
    <nav className="navbar">
      <div className="nav-left">
        <div className="logo">
          <span className="highlight">Gaming</span> App
        </div>

        <ul className="nav-links">
          <li>
            <button
              className={currentPage === "home" ? "nav-link active" : "nav-link"}
              onClick={() => goToPage("home")}
            >
              Home
            </button>
          </li>

          <li>
            <button
              className={currentPage === "store" ? "nav-link active" : "nav-link"}
              onClick={() => goToPage("store")}
            >
              Store
            </button>
          </li>

          {user && (
            <li>
              <button
                className={currentPage === "trade" ? "nav-link active" : "nav-link"}
                onClick={() => goToPage("trade")}
              >
                Trade-In
              </button>
            </li>
          )}

          {user && (
            <li>
              <button
                className={currentPage === "library" ? "nav-link active" : "nav-link"}
                onClick={() => goToPage("library")}
              >
                Library
              </button>
            </li>
          )}

          {user && (
            <li>
              <button
                className={currentPage === "profile" ? "nav-link active" : "nav-link"}
                onClick={() => goToPage("profile")}
              >
                Profile
              </button>
            </li>
          )}

          {user && (
            <li>
              <button
                className={currentPage === "cart" ? "nav-link active" : "nav-link"}
                onClick={() => goToPage("cart")}
              >
                Cart ({cart.length})
              </button>
            </li>
          )}

          {user && (user?.role === "dev"|| user.role === "admin") && (
            <li>
              <button
                className={currentPage === "publish" ? "nav-link active" : "nav-link"}
                onClick={() => goToPage("publish")}
              >
                Publish
              </button>
            </li>
          )}



        </ul>
      </div>

      <div className="nav-right">
        {!user ? (
          <button
            className="signin-btn"
            onClick={() => goToPage("signin")}
          >
            Sign In
          </button>
        ) : (
          <button className="signin-btn" onClick={onSignOut}>
            Sign Out ({user.username})
          </button>
        )}
      </div>
    </nav>
  );
}

// ---------------- HOME ----------------
function Home({ walletAddress, walletBalance, onConnectWallet }) {
  const [connecting, setConnecting] = useState(false);

  const handleClick = async () => {
    setConnecting(true);
    try {
      await onConnectWallet();
    } finally {
      setConnecting(false);
    }
  };

  const label = walletAddress
    ? `Wallet: ${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`
    : "Connect Wallet";

  return (
    <div className="home-page">
      <div className="overlay">
        <h1 className="home-title">Welcome to Gaming App Dashboard</h1>
        <p className="home-subtitle">
          Manage your blockchain-backed game ownership, verify licenses,
          transfer rights, and connect your wallet — securely.
        </p>

        <button className="connect-btn" onClick={handleClick} disabled={connecting}>
          {connecting ? "Connecting..." : label}
        </button>
      </div>
    </div>
  );
}

// ---------------- SIGN IN / SIGN UP PAGE ----------------
function SignIn({ onAuth, goToPage }) {
  const [mode, setMode] = useState("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("user"); 
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const endpoint = mode === "login" ? "/api/login" : "/api/register";

    const payload =
      mode === "login"
        ? { username, password }
        : { username, password, role }; // include role when registering

    try {
      const res = await fetch("http://localhost:4000" + endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Request failed");
      } else {
        onAuth({
          userId: data.userId,
          username: data.username,
          walletAddress: data.walletAddress || null,
          role: data.role || "user",
        });
        goToPage("profile");
      }
    } catch (err) {
      console.error(err);
      setError("Network error – is the server running on :4000?");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <div className="card">
        <h2>{mode === "login" ? "Sign In" : "Create Account"}</h2>

        <form onSubmit={handleSubmit}>
          {/* Username */}
          <div className="form-field">
            <label>Username</label>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          {/* Password */}
          <div className="form-field">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {/* Role dropdown (ONLY in Sign Up mode) */}
          {mode === "register" && (
            <div className="form-field">
              <label>Account Type</label>
              <select value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="user">User</option>
                <option value="dev">Developer</option>
              </select>
            </div>
          )}

          <button className="primary-btn" type="submit" disabled={loading}>
            {loading
              ? "Please wait..."
              : mode === "login"
              ? "Sign In"
              : "Create Account"}
          </button>

          {error && <div className="error-text">{error}</div>}
        </form>

        {/* Switch Modes */}
        <div className="mode-toggle">
          {mode === "login" ? (
            <>
              No account yet?{" "}
              <button
                type="button"
                onClick={() => {
                  setMode("register");
                  setError("");
                }}
              >
                Sign up
              </button>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <button
                type="button"
                onClick={() => {
                  setMode("login");
                  setError("");
                }}
              >
                Sign in
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}


// ---------------- STORE PAGE ----------------
function Store({ user, cart, setCart, goToPage, libraryGames }) {
  const [games, setGames] = useState([]);
  const [genres, setGenres] = useState([]);
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [carouselIndex, setCarouselIndex] = useState(0);

  useEffect(() => {
    fetch("http://localhost:4000/api/games")
      .then((res) => res.json())
      .then((data) => {
        setGames(data);
        setGenres([...new Set(data.map((g) => g.genre))]);
      });
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCarouselIndex((i) => {
        if (games.length === 0) return 0;
        return (i + 1) % Math.min(games.length, 3);
      });
    }, 3000);
    return () => clearInterval(timer);
  }, [games]);

  const ownedIds = new Set(
    (libraryGames || []).map((g) => g.game_id)
  );

  const filteredGames =
    selectedGenres.length === 0
      ? games
      : games.filter((g) => selectedGenres.includes(g.genre));

  const toggleGenre = (genre) => {
    if (selectedGenres.includes(genre)) {
      setSelectedGenres(selectedGenres.filter((g) => g !== genre));
    } else {
      setSelectedGenres([...selectedGenres, genre]);
    }
  };

  const isInCart = (gameId) => cart.some((g) => g.id === gameId);

  const addToCart = (game) => {
    if (!isInCart(game.id)) {
      setCart([...cart, game]);
    }
  };

  const removeFromCart = (gameId) => {
    setCart(cart.filter((g) => g.id !== gameId));
  };

  const handleCartToggle = (game) => {
    if (isInCart(game.id)) {
      removeFromCart(game.id);
    } else {
      addToCart(game);
    }
  };

  const handleBuyNow = (game) => {
    // Ensure it's in the cart
    if (!isInCart(game.id)) {
      setCart([...cart, game]);
    }
    // Go straight to checkout
    goToPage("checkout");
  };

  return (
    <div className="store-page">
      <div className="store-container">
        {/* Sidebar */}
        <div className="store-sidebar">
          <h3>Filter by Genre</h3>
          {genres.map((genre) => (
            <label key={genre} className="genre-checkbox">
              <input
                type="checkbox"
                checked={selectedGenres.includes(genre)}
                onChange={() => toggleGenre(genre)}
              />
              {genre}
            </label>
          ))}
        </div>

        {/* Main Store Content */}
        <div style={{ width: "100%" }}>
          {/* Carousel */}
          <div className="carousel">
            {games.length > 0 && <img src={games[carouselIndex].cover_img} />}
            <div className="carousel-title">🔥 Hot Games</div>
          </div>

          {/* Grid */}
          <div className="game-grid">
            {filteredGames.map((game) => {
              const owned = ownedIds.has(game.id);

              return (
                <div className="game-card" key={game.id}>
                  <img src={game.cover_img} alt={game.name} />
                  <div className="hover-info">
                    <h4>{game.name}</h4>
                    <p>{game.description}</p>

                    {user ? (
                      owned ? (
                        <>
                          <button
                            className="card-btn buy-now-btn"
                            onClick={() => goToPage("library")}
                          >
                            Play Now
                          </button>
                          <button
                            className="card-btn add-to-cart-btn"
                            onClick={() => goToPage("library")}
                          >
                            Go to Library
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            className="card-btn add-to-cart-btn"
                            onClick={() => handleCartToggle(game)}
                          >
                            {isInCart(game.id) ? "Remove from Cart" : "Add to Cart"}
                          </button>

                          <button
                            className="card-btn buy-now-btn"
                            onClick={() => handleBuyNow(game)}
                          >
                            Buy Now
                          </button>
                        </>
                      )
                    ) : (
                      <p style={{ color: "white", marginTop: "10px" }}>
                        Sign in to purchase.
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------------- Trade-In PAGE ----------------
function TradeIn({ user, libraryGames, onTradeInComplete }) {
  const { useState, useEffect } = React;

  const [ownedQuery, setOwnedQuery] = useState("");
  const [storeQuery, setStoreQuery] = useState("");
  const [selectedIds, setSelectedIds] = useState([]);
  const [storeGames, setStoreGames] = useState([]);
  const [loading, setLoading] = useState(false);

  if (!user) {
    return (
      <div className="page">
        <div className="card">
          <h2>Trade-In</h2>
          <p>You must be signed in to trade in games.</p>
        </div>
      </div>
    );
  }

  // Load full store catalog once so we can show trade-in values for ANY title
  useEffect(() => {
    fetch("http://localhost:4000/api/games")
      .then((res) => res.json())
      .then((data) => setStoreGames(data || []))
      .catch((e) => console.error("Failed to load store games for trade-in:", e));
  }, []);

  // --- helper: get trade-in value (70% of price) in CFLR float ---
  function getTradeInValueCflr(priceWeiText) {
    try {
      if (!priceWeiText) return 0;
      const priceWeiBig = BigInt(priceWeiText);
      const tradeWei = (priceWeiBig * BigInt(70)) / BigInt(100); // 70%
      // convert wei BigInt -> CFLR number for display
      const tradeStr = tradeWei.toString();
      // ethers.utils.formatEther needs a string
      const ethStr = ethers.utils.formatEther(tradeStr);
      return parseFloat(ethStr);
    } catch (e) {
      console.error("Bad price_wei for trade-in:", priceWeiText, e);
      return 0;
    }
  }

  // --- filter owned (library) games by search ---
  const ownedFiltered = (libraryGames || []).filter((g) => g.acquired_via !== "shared") .filter((g) => {
    const name = (g.name || "").toLowerCase();  //guard against undefined
    const q = ownedQuery.toLowerCase();
    return name.includes(q);
  });

  // --- filter store catalog by search for "what's this game's trade-in value?" ---
  const storeFiltered = (storeGames || []).filter((g) => {
    const name = (g.name || "").toLowerCase();
    const q = storeQuery.toLowerCase();
    return name.includes(q);
  });

  // --- selection logic for owned games ---
  const toggleSelect = (gameId) => {
    setSelectedIds((prev) =>
      prev.includes(gameId)
        ? prev.filter((id) => id !== gameId)
        : [...prev, gameId]
    );
  };

  // total trade-in credit for currently selected owned games
  const totalSelectedTradeCflr = (() => {
    if (!libraryGames || selectedIds.length === 0) return 0;
    let sum = 0;
    for (const gid of selectedIds) {
      const g = libraryGames.find((x) => x.game_id === gid);
      if (!g || !g.price_wei) continue;
      sum += getTradeInValueCflr(g.price_wei);
    }
    return sum;
  })();

  // --- call backend to perform trade-in ---
  const handleTradeIn = async () => {
    if (!user) return;
    if (!libraryGames || selectedIds.length === 0) return;

    // map selected game_ids -> token_ids
    const selectedTokenIds = selectedIds
      .map((gid) => libraryGames.find((g) => g.game_id === gid))
      .filter(Boolean)
      .map((g) => g.token_id);

    if (selectedTokenIds.length === 0) {
      alert("No tokens found for selected games.");
      return;
    }

    const confirmMsg =
      `Trade in ${selectedTokenIds.length} game(s)?\n` +
      `You will receive approximately ${totalSelectedTradeCflr.toFixed(4)} CFLR in store credit.`;
    if (!window.confirm(confirmMsg)) return;

    try {
      setLoading(true);
      const res = await fetch("http://localhost:4000/api/trade-in", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.userId,
          tokenIds: selectedTokenIds,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        console.error("Trade-in error:", data);
        alert(data.error || "Trade-in failed.");
        return;
      }

      alert("Trade-in complete! Store credit updated.");
      setSelectedIds([]);
      if (onTradeInComplete) {
        await onTradeInComplete();
      }
    } catch (e) {
      console.error("Trade-in failed:", e);
      alert("Trade-in failed – see console for details.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <div className="card">
        <h2>Trade-In</h2>
        <p>
          Trade in games you own for store credit, and check estimated trade-in
          values for any title in the catalog.
        </p>

        {/* ========== SECTION 1: Catalog search for trade-in value ========== */}
        <div style={{ marginTop: "20px", marginBottom: "10px" }}>
          <h3>Check Trade-In Values (All Games)</h3>
          <div className="form-field">
            <label>Search store catalog</label>
            <input
              placeholder="Type a game title..."
              value={storeQuery}
              onChange={(e) => setStoreQuery(e.target.value)}
            />
          </div>

          <div className="tradein-store-results">
            {storeQuery && storeFiltered.length === 0 && (
              <p>No matching games in the store catalog.</p>
            )}

            {storeFiltered.slice(0, 10).map((g) => {
              const val = getTradeInValueCflr(g.price_wei);
              return (
                <div
                  key={g.id}
                  className="tradein-row"
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    padding: "4px 0",
                  }}
                >
                  <span>{g.name}</span>
                  <span style={{ opacity: 0.8 }}>
                    Est. trade-in: {val.toFixed(4)} CFLR
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <hr style={{ margin: "20px 0" }} />

        {/* ========== SECTION 2: Owned games you can trade in ========== */}
        <h3>Your Owned Games (Trade-In Eligible)</h3>

        <div className="form-field">
          <label>Search your library</label>
          <input
            placeholder="Search owned games..."
            value={ownedQuery}
            onChange={(e) => setOwnedQuery(e.target.value)}
          />
        </div>

        <div className="library-grid">
          {ownedFiltered.length === 0 ? (
            <p style={{ marginTop: "10px" }}>
              No owned games match this search.
            </p>
          ) : (
            ownedFiltered.map((g) => {
              const isSelected = selectedIds.includes(g.game_id);
              const tradeVal = getTradeInValueCflr(g.price_wei);

              return (
                <div
                  key={g.game_id}
                  className={
                    "library-item" + (isSelected ? " selected-trade" : "")
                  }
                >
                  <div className="library-cover">
                    <div className="cover-placeholder">{g.name[0]}</div>
                  </div>
                  <div className="library-title">{g.name}</div>
                  <div style={{ fontSize: "0.85rem", opacity: 0.8 }}>
                    Trade-in value: {tradeVal.toFixed(4)} CFLR
                  </div>

                  <button
                    className="secondary-btn"
                    style={{ marginTop: "8px" }}
                    onClick={() => toggleSelect(g.game_id)}
                  >
                    {isSelected ? "Remove from Trade-In" : "Add to Trade-In"}
                  </button>
                </div>
              );
            })
          )}
        </div>

        {selectedIds.length > 0 && (
          <>
            <p style={{ marginTop: "10px" }}>
              Selected games: {selectedIds.length} · Total trade-in credit:{" "}
              {totalSelectedTradeCflr.toFixed(4)} CFLR
            </p>
            <button
              className="primary-btn"
              style={{ marginTop: "10px" }}
              disabled={loading}
              onClick={handleTradeIn}
            >
              {loading ? "Processing..." : "Trade In Selected"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}


// ---------------- PUBLISH PAGE (Dev Upload / Update) ----------------
function Publish({ user }) {
  const [name, setName] = useState("");
  const [manifestUrl, setManifestUrl] = useState("");
  const [priceWei, setPriceWei] = useState("");
  const [genre, setGenre] = useState("");
  const [coverImg, setCoverImg] = useState("");
  const [description, setDescription] = useState("");
  const [versionLabel, setVersionLabel] = useState("v1.0.0");

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [launchUrl, setLaunchUrl] = useState("");
  const [myGames, setMyGames] = useState([]);
  const [editingGame, setEditingGame] = useState(null); // game being edited

  useEffect(() => {
    if (!user || (user.role !== "dev" && user.role !== "admin")) return;

    async function loadMyGames() {
      try {
        const res = await fetch(
          `http://localhost:4000/api/dev/my-games/${user.userId}`
        );
        const data = await res.json();
        if (!res.ok) {
          console.error("Failed to load my games:", data);
          return;
        }
        setMyGames(data || []);
      } catch (e) {
        console.error("Network error loading my games:", e);
      }
    }

    loadMyGames();
  }, [user])

  if (!user || (user.role !== "dev" && user.role !== "admin")) {
    return (
      <div className="page">
        <div className="card">
          <h2>Publish Game</h2>
          <p>You are not authorized to publish games.</p>
        </div>
      </div>
    );
  }

    const startEdit = (game) => {
  setEditingGame(game);
  setName(game.name || "");
  setManifestUrl(game.manifest_url || "");
  setPriceWei(
    game.price_wei != null ? String(game.price_wei) : ""
  );
  setGenre(game.genre || "");
  setCoverImg(game.cover_img || "");
  setDescription(game.description || "");
  setVersionLabel(game.version_label || "v1.0.0");
  setLaunchUrl(game.launch_url || "");
};

  const handleDelete = async (gameId) => {
    if (!window.confirm("Remove this game from the store?")) return;

    try {
      const res = await fetch(
        `http://localhost:4000/api/dev/games/${gameId}`,
        {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ publisher_id: user.userId }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        console.error("Delete failed:", data);
        alert(data.error || "Failed to remove game.");
        return;
      }
      setMyGames((prev) => prev.filter((g) => g.id !== gameId));
      alert("Game removed from store.");
    } catch (e) {
      console.error("Delete error:", e);
      alert("Network error removing game.");
    }
  };


    const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    setLoading(true);

    let priceWeiText;
    try {
      // assume dev types in CFLR, e.g. "1.0"
      priceWeiText = ethers.utils.parseEther(priceWei || "0").toString();
    } catch (e) {
      setMessage("Price must be a valid number (CFLR).");
      setLoading(false);
      return;
    }

    const payload = {
      name,
      manifest_url: manifestUrl,
      price_wei: priceWeiText,
      genre,
      cover_img: coverImg,
      description,
      version_label: versionLabel,
      publisher_id: user.userId,
      active: 1,
      launch_url: launchUrl,       
    };

    const url = editingGame
      ? `http://localhost:4000/api/dev/games/${editingGame.id}`
      : "http://localhost:4000/api/dev/games";

    const method = editingGame ? "PUT" : "POST";

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        console.error("Publish/update failed:", data);
        setMessage(data.error || "Failed to publish/update game.");
      } else {
        setMessage(
          editingGame
            ? "Game updated successfully."
            : `Game published! New game id = ${data.gameId}.`
        );
        setEditingGame(null);
        // reload myGames
        const res2 = await fetch(
          `http://localhost:4000/api/dev/my-games/${user.userId}`
        );
        const data2 = await res2.json();
        if (res2.ok) setMyGames(data2 || []);
      }
    } catch (err) {
      console.error("Publish/update error:", err);
      setMessage("Network error while publishing/updating game.");
    } finally {
      setLoading(false);
    }
  };





    return (
    <div className="page">
      <div className="card">
        <h2>Publish / Update Game</h2>
        <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
  <div className="form-field">
    <label>Game Title</label>
    <input
      value={name}
      onChange={(e) => setName(e.target.value)}
      required
    />
  </div>

  <div className="form-field">
    <label>Manifest URL</label>
    <input
      value={manifestUrl}
      onChange={(e) => setManifestUrl(e.target.value)}
      placeholder="https://.../manifest.json"
      required
    />
  </div>

  <div className="form-field">
    <label>Price (CFLR)</label>
    <input
      value={priceWei}
      onChange={(e) => setPriceWei(e.target.value)}
      placeholder="e.g. 1.0"
      required
    />
  </div>

  <div className="form-field">
    <label>Genre</label>
    <input
      value={genre}
      onChange={(e) => setGenre(e.target.value)}
      placeholder="Roguelike, Deckbuilder..."
    />
  </div>

  <div className="form-field">
    <label>Cover Image URL</label>
    <input
      value={coverImg}
      onChange={(e) => setCoverImg(e.target.value)}
      placeholder="https://.../cover.png"
    />
  </div>

  <div className="form-field">
    <label>Description</label>
    <textarea
      value={description}
      onChange={(e) => setDescription(e.target.value)}
      rows={3}
    />
  </div>

  <div className="form-field">
  <label>Launch URL (exe/zip/web build)</label>
  <input
    placeholder="https://example.com/downloads/tiny-deck-setup.exe"
    value={launchUrl}
    onChange={(e) => setLaunchUrl(e.target.value)}
  />
  <small style={{ fontSize: "0.8rem", opacity: 0.7 }}>
    This is the link opened when users click “Launch” in their library.
  </small>
</div>


  <div className="form-field">
    <label>Version Label</label>
    <input
      value={versionLabel}
      onChange={(e) => setVersionLabel(e.target.value)}
      placeholder="v1.0.0"
    />
  </div>

  <button className="primary-btn" type="submit" disabled={loading}>
    {loading ? "Saving..." : editingGame ? "Update Game" : "Publish Game"}
  </button>
</form>

        {message && (
          <div style={{ marginTop: "10px", fontSize: "0.9rem" }}>{message}</div>
        )}

        <hr style={{ margin: "20px 0" }} />

        <h3>Your Published Games</h3>
        {myGames.length === 0 ? (
          <p>No games published yet.</p>
        ) : (
          <div className="dev-games-list">
            {myGames.map((g) => (
              <div key={g.id} className="purchase-row">
                <div>
                  <div>
                    <strong>{g.name}</strong>{" "}
                    <span style={{ fontSize: "0.85rem", opacity: 0.8 }}>
                      ({g.version_label || "v1.0.0"})
                    </span>
                  </div>
                  <div style={{ fontSize: "0.85rem", opacity: 0.8 }}>
                    Copies sold: {g.copies_sold || 0} · Active:{" "}
                    {g.active ? "Yes" : "No"}
                  </div>
                </div>
                <div>
                  <button
                    className="secondary-btn"
                    onClick={() => startEdit(g)}
                    style={{ marginRight: "5px" }}
                  >
                    Edit
                  </button>
                  <button
                    className="secondary-btn"
                    onClick={() => handleDelete(g.id)}
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}



// ---------------- Cart PAGE ----------------
function Cart({ cart, setCart, goToPage }) {
  const totalItems = cart.length;

  const removeItem = (indexToRemove) => {
    setCart(cart.filter((_, idx) => idx !== indexToRemove));
  };

  return (
    <div className="page">
      <div className="card">
        <h2>Your Cart</h2>
        <p>Total items: {totalItems}</p>

        {cart.length === 0 && <p>Your cart is empty.</p>}

        {cart.map((game, idx) => (
          <div
            key={idx}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "6px",
            }}
          >
            <span>• {game.name}</span>
            <button
              style={{
                border: "none",
                borderRadius: "6px",
                padding: "4px 8px",
                background: "#ff8080",
                color: "#000",
                cursor: "pointer",
                fontSize: "0.8rem",
              }}
              onClick={() => removeItem(idx)}
            >
              Remove
            </button>
          </div>
        ))}

        {cart.length > 0 && (
          <button
            className="primary-btn"
            onClick={() => goToPage("checkout")}
            style={{ marginTop: "15px" }}
          >
            Proceed to Checkout
          </button>
        )}
      </div>
    </div>
  );
}

// ---------------- Checkout PAGE ----------------
function Checkout({ cart, user, walletAddress, goToPage, onPurchaseComplete, storeCreditWei  }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const totalWei = cart.reduce((sum, g) => sum + Number(g.price_wei || 0), 0);
  const totalCflr = totalWei / 1e18;

  // Convert store credit TEXT wei to number CFLR for display
  let creditCflr = 0;
  try {
    creditCflr = parseFloat(
      ethers.utils.formatEther(storeCreditWei || "0")
    );
  } catch (e) {
    console.error("Bad storeCreditWei:", storeCreditWei, e);
    creditCflr = 0;
  }

  const effectiveTotalCflr = Math.max(totalCflr - creditCflr, 0);
  

  async function handleConfirmPurchase() {
  try {
    if (!window.ethereum) {
      alert("MetaMask not detected.");
      return;
    }

    console.log("Preparing ethers v5 purchase…");

    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();

    const contract = new ethers.Contract(
      GAME_OWNERSHIP_ADDRESS,
      GAME_OWNERSHIP_ABI,
      signer
    );

    const iface = new ethers.utils.Interface(GAME_OWNERSHIP_ABI);

    for (const game of cart) {
      // Prefer explicit on-chain game id if you added that column
      const gameIdOnChain = game.contract_game_id ?? game.id;

      
      let priceWeiStr = game.price_wei;

      console.log("DEBUG game:", game);
      console.log("DEBUG raw price_wei from DB:", priceWeiStr);

      if (!priceWeiStr || priceWeiStr.trim() === "") {
        console.error("FATAL: price_wei missing from game:", game);
        alert("Game price is missing. Contact admin.");
        return;
      }

      // Always convert TEXT → BigNumber
      let priceWei;
      try {
        priceWei = ethers.BigNumber.from(String(priceWeiStr));
      } catch (e) {
        console.error("Invalid price_wei:", priceWeiStr, e);
        alert("Game price format invalid. Cannot process purchase.");
        return;
      }

      console.log("Sending buyGame tx:", {
        gameIdOnChain,
        priceWei: priceWei.toString(),
      });

      // IMPORTANT: use priceWei (BigNumber), not game.price_wei
      const tx = await contract.buyGame(gameIdOnChain, { value: priceWei });

      console.log("Transaction sent:", tx.hash);

      const receipt = await tx.wait();
      console.log("Purchase confirmed:", receipt);

      // Parse GamePurchased event to get tokenId
      let tokenId = null;
      for (const log of receipt.logs) {
        try {
          const parsed = iface.parseLog(log);
          if (parsed.name === "GamePurchased") {
            tokenId = parsed.args.tokenId.toString();
            break;
          }
        } catch (e) {
          // ignore logs that don't match this ABI
        }
      }

      console.log("Parsed tokenId:", tokenId);

      // Record purchase in backend
      await fetch("http://localhost:4000/api/purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.userId,
          gameId: game.id,                  // DB game id
          tokenId,                          // on-chain token id
          txHash: tx.hash,
          fromAddress: user.walletAddress || walletAddress,
          toAddress: GAME_OWNERSHIP_ADDRESS,
        }),
      });
    }

    alert("Purchase Complete!");
    onPurchaseComplete();
  } catch (err) {
    console.error("Purchase failed:", err);
    alert("Purchase failed — see console for details.");
  }
}






  return (
    <div className="page">
      <div className="card">
        <h2>Checkout</h2>

        {cart.length === 0 ? (
          <p>Your cart is empty.</p>
        ) : (
          <>
            <ul style={{ textAlign: "left" }}>
              {cart.map((g, idx) => (
                <li key={idx}>
                  {g.name} – {(Number(g.price_wei || 0) / 1e18).toFixed(4)} CFLR
                </li>
              ))}
            </ul>
            <p><strong>Total:</strong> {totalCflr.toFixed(4)} CFLR</p>
            <p><strong>Store credit:</strong> {creditCflr.toFixed(4)} CFLR</p>
            <p><strong>Effective total (conceptual):</strong> {effectiveTotalCflr.toFixed(4)} CFLR</p>


            <button
              className="primary-btn"
              disabled={loading}
              onClick={handleConfirmPurchase}
            >
              {loading ? "Processing..." : "Confirm Purchase"}
            </button>
          </>
        )}

        {error && <div className="error-text" style={{ marginTop: 10 }}>{error}</div>}
        {success && <div style={{ marginTop: 10, color: "#66ff99" }}>{success}</div>}
      </div>
    </div>
  );
}



// ---------------- LIBRARY PAGE ----------------
function Library({ user, libraryGames }) {
  const [expandedGameId, setExpandedGameId] = useState(null);
  const [selectedVersion, setSelectedVersion] = useState("latest");

  if (!user) {
    return (
      <div className="page">
        <div className="card">
          <h2>Library</h2>
          <p>You must be signed in to view your game library.</p>
        </div>
      </div>
    );
  }

  
  const games = Array.isArray(libraryGames) ? libraryGames : [];
  

  if (games.length === 0) {
    return (
      <div className="page">
        <div className="card">
          <h2>Your Library</h2>
          <p>You don&apos;t own any games yet. Visit the Store to purchase.</p>
        </div>
      </div>
    );
  }

  const toggleDropdown = (gameId) => {
    setExpandedGameId(expandedGameId === gameId ? null : gameId);
  };

  const handlePlay = (game) => {
  console.log("Play game:", game.name, "version:", selectedVersion);

  const url = game.launch_url || game.manifest_url;
  if (!url) {
    alert("No launch URL configured for this game yet.");
    return;
  }

  window.open(url, "_blank", "noopener,noreferrer");
};

const handleShare = async (game) => {
    if (!user) return;
    if (game.acquired_via !== "purchase") {
      alert("You can only share games you purchased (not shared copies).");
      return;
    }

    const friendUsername = window.prompt(
      "Enter the username of the friend to share this game with:"
    );
    if (!friendUsername || friendUsername.trim() === "") return;

    try {
      

      const addRes = await fetch("http://localhost:4000/api/friends/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.userId,
          friendUsername: friendUsername.trim(),
        }),
      });
      const addData = await addRes.json();
      if (!addRes.ok) {
        console.error("Add friend failed:", addData);
        alert(addData.error || "Failed to add friend.");
        return;
      }

      const friendId = addData.friendId;

      const shareRes = await fetch("http://localhost:4000/api/share-game", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ownerId: user.userId,
          friendId,
          gameId: game.game_id,
        }),
      });
      const shareData = await shareRes.json();
      if (!shareRes.ok) {
        console.error("Share game failed:", shareData);
        alert(shareData.error || "Failed to share game.");
        return;
      }

      alert("Game shared successfully!");
    } catch (e) {
      console.error("Share game error:", e);
      alert("Network error while sharing game.");
    }
  };

  
  

  async function stopSharingGame(gameId) {

   const friendUsername = window.prompt(
      "Enter the username of the friend to share this game with:"
    );
    if (!friendUsername || friendUsername.trim() === "") return;

    try {

      const addRes = await fetch("http://localhost:4000/api/friends/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.userId,
          friendUsername: friendUsername.trim(),
        }),
      });
      const addData = await addRes.json();
      if (!addRes.ok) {
        console.error("Add friend failed:", addData);
        alert(addData.error || "Failed to add friend.");
        return;
      }

      const friendId = addData.friendId;
    const res = await fetch("http://localhost:4000/api/share-game/stop", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ownerId: user.userId,
        friendId,
        gameId,
      }),
    });

    const data = await res.json();
    if (!res.ok) {
      alert(data.error || "Failed to stop sharing.");
      return;
    }

    alert("Sharing stopped. The friend’s library will no longer show this game.");
    //  refresh the owner's share UI or some list here
  } catch (e) {
    console.error("Stop sharing error:", e);
    alert("Network error while stopping sharing.");
  }
}


  return (
    <div className="page">
      <div className="card">
        <h2>Your Library</h2>
        <div className="library-grid">
          {games.map((g) => (
            <div
              key={g.game_id}
              className="library-item"
              onMouseEnter={() => setExpandedGameId(g.game_id)}
              onMouseLeave={() => setExpandedGameId(null)}
            >
              <div className="library-cover">
                <div className="cover-placeholder">{g.name[0]}</div>
              </div>
              <div className="library-title">
                {g.name}
                {g.active === 0 && (
                  <span style={{ fontSize: "0.75rem", marginLeft: 6, opacity: 0.7 }}>
                    · Removed from store (version locked)
                  </span>
                )}
              </div>


              {expandedGameId === g.game_id && (
                <div className="library-hover-panel">
                  <button
                    className="primary-btn"
                    onClick={() => toggleDropdown(g.game_id)}
                  >
                    Play Game
                  </button>

                  <button
                    className="secondary-btn"
                    style={{ marginTop: "6px" }}
                    onClick={() => handleShare(g)}
                  >
                    Share Game
                  </button>

                  <button
                    className="secondary-btn"
                    onClick={() => stopSharingGame(g.game_id)}
                  >
                    Stop Sharing
                  </button>

                   


                {expandedGameId === g.game_id && (
                        <div className="version-dropdown">
                          <label>
                            Version:{" "}
                            <select
                              value={selectedVersion}
                              onChange={(e) => setSelectedVersion(e.target.value)}
                            >
                              <option value="latest">
                                Frozen: {g.version_label || "v1.0.0"}
                              </option>
                            </select>
                          </label>
                          <button
                            className="primary-btn"
                            style={{ marginTop: "8px" }}
                            onClick={() => handlePlay(g)}
                          >
                            Launch
                          </button>
                        </div>
                      )}
                    </div>
                  )}

            </div>
          ))}
        </div>
      </div>
    </div>
  );
}



// ---------------- PROFILE PAGE ----------------
function Profile({
  user,
  walletAddress,
  walletBalance,
  onConnectWallet,
  goToPage,
  purchaseHistory,
  onRefund,
}) {
  const [linking, setLinking] = useState(false);
  const [error, setError] = useState("");
  const [showFriends, setShowFriends] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [friends, setFriends] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);  // 👈 NEW

  
  

  console.log("Profile render:", { walletAddress, walletBalance });

  if (!user) {
    return (
      <div className="page">
        <div className="card">
          <h2>Not signed in</h2>
          <p>Please sign in to view your profile.</p>
        </div>
      </div>
    );
  }

  const effectiveWallet = user.walletAddress || walletAddress || null;

  // Load actual friends list
  useEffect(() => {
    if (!user) return;
    loadFriends();
    loadPendingRequests();
  }, [user]);

    async function loadFriends() {
  try {
    const res = await fetch(
      `http://localhost:4000/api/friends/list/${user.userId}`
    );
    const data = await res.json();
    if (res.ok) {
      setFriends(data || []);
    } else {
      console.error("Load friends failed:", data);
    }
  } catch (e) {
    console.error("Load friends failed:", e);
  }
}

async function loadPendingRequests() {
  try {
    const res = await fetch(
      `http://localhost:4000/api/friends/requests/${user.userId}`
    );
    const data = await res.json();
    if (res.ok) {
      setPendingRequests(data || []);
    } else {
      console.error("Load pending requests failed:", data);
    }
  } catch (e) {
    console.error("Load pending requests failed:", e);
  }
}



  async function searchUsers(q) {
    setSearchText(q);

    if (q.length < 2) {
      setSearchResults([]);
      return;
    }

    try {
      const res = await fetch(`http://localhost:4000/api/users/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      setSearchResults(data || []);
    } catch (e) {
      console.error("Search users failed:", e);
    }
  }

  async function sendFriendRequest(targetId) {
    try {
      const res = await fetch("http://localhost:4000/api/friends/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fromUserId: user.userId,
          toUserId: targetId
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Friend request failed");
      } else {
        alert("Friend request sent!");
      }
    } catch (e) {
      console.error("Friend request error:", e);
      alert("Network error sending friend request");
    }
  }

    async function respondToRequest(reqId, accept) {
    try {
      const res = await fetch("http://localhost:4000/api/friends/respond", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requestId: reqId,
          userId: user.userId,
          accept
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Failed to respond to request");
        return;
      }

      if (accept) {
        alert("Friend request accepted!");
        await loadFriends();
      } else {
        alert("Friend request declined.");
      }
      await loadPendingRequests();
    } catch (e) {
      console.error("Respond to request error:", e);
      alert("Network error responding to friend request");
    }
  }

   

  const handleClick = async () => {
    setError("");
    setLinking(true);
    try {
      await onConnectWallet();
    } catch (e) {
      console.error(e);
      setError("Failed to connect wallet.");
    } finally {
      setLinking(false);
    }
  };

  return (
    <div className="page">
      <div className="card">
        <h2>User Profile</h2>

        <div className="profile-details">
          {/* --- BASIC PROFILE INFO --- */}
          <p>
            <strong>Username:</strong> {user.username}
          </p>
          <p>
            <strong>User ID:</strong> {user.userId}
          </p>

          <p>
            <strong>Wallet:</strong>{" "}
            {effectiveWallet ? (
              <span>{effectiveWallet}</span>
            ) : (
              <span style={{ color: "#ff8080" }}>Not connected</span>
            )}
          </p>

          <p>
            <strong>Balance (CFLR):</strong>{" "}
            {walletBalance != null ? (
              <span>{walletBalance} CFLR</span>
            ) : (
              <span>—</span>
            )}
          </p>

          {!effectiveWallet && (
            <button
              className="primary-btn"
              onClick={handleClick}
              disabled={linking}
              style={{ marginTop: "15px" }}
            >
              {linking ? "Connecting..." : "Connect Wallet"}
            </button>
          )}

          <button
            className="primary-btn"
            style={{ marginTop: "15px" }}
            onClick={() => goToPage("library")}
          >
            Go to Library
          </button>

          {error && <div className="error-text">{error}</div>}

        

          <h3 style={{ marginTop: "24px" }}>Purchase History</h3>

          {!purchaseHistory || purchaseHistory.length === 0 ? (
            <p>No purchases yet.</p>
          ) : (
            <div className="purchase-history-list">
              {purchaseHistory.map((tx) => (
                <div key={tx.id} className="purchase-row">
                  <div>
                    <div>
                      <strong>{tx.game_name || `Game #${tx.game_id}`}</strong>
                    </div>

                    <div style={{ fontSize: "0.85rem", opacity: 0.8 }}>
                      Token #{tx.token_id} · {tx.type} · {tx.created_at}
                    </div>

                    <div style={{ fontSize: "0.8rem", opacity: 0.7 }}>
                      Tx: {tx.tx_hash?.slice(0, 10)}...
                    </div>
                  </div>

                  <div>
                    <button
                      className="secondary-btn"
                      onClick={() => {
                        const choice = window.prompt(
                          'Type "return" to refund this game, or "trade" to go to the Trade-In page:'
                        );
                        if (!choice) return;

                        const c = choice.toLowerCase().trim();

                        if (c.startsWith("ret")) {
                          // do on-chain refund + DB update
                          onRefund(tx);
                        } else if (c.startsWith("tra")) {
                          // navigate to Trade-In page; user can pick games there
                          goToPage("trade");
                        } else {
                          alert('Invalid choice. Please type "return" or "trade".');
                        }
                      }}
                    >
                      Return / Trade
                    </button>


                  </div>
                </div>
              ))}
            </div>
          )}

          

            <div style={{ marginTop: "25px" }}>
    <button
      className="secondary-btn"
      onClick={() => setShowFriends(!showFriends)}
      style={{ position: "relative" }}
    >
      Friends
      {pendingRequests.length > 0 && (
        <span
          style={{
            position: "absolute",
            top: "-4px",
            right: "-8px",
            backgroundColor: "#ff5555",
            color: "#fff",
            borderRadius: "999px",
            padding: "0 6px",
            fontSize: "0.7rem",
          }}
        >
          {pendingRequests.length}
        </span>
      )}
    </button>

    {showFriends && (
      <div className="card" style={{ marginTop: "15px" }}>
        {/* Friends list */}
        <h3>Your Friends</h3>
        {friends.length === 0 ? (
          <p>No friends yet.</p>
        ) : (
          <ul>
            {friends.map((f) => (
              <li key={f.id}>{f.username}</li>
            ))}
          </ul>
        )}

        <hr />

        {/* Friend requests inbox */}
        <h4>Friend Requests</h4>
        {pendingRequests.length === 0 ? (
          <p>No pending requests.</p>
        ) : (
          <div>
            {pendingRequests.map((r) => (
              <div key={r.id} className="purchase-row">
                <span>
                  <strong>{r.from_username}</strong> sent you a request
                </span>
                <div>
                  <button
                    className="primary-btn"
                    style={{ marginRight: "5px" }}
                    onClick={() => respondToRequest(r.id, true)}
                  >
                    Accept
                  </button>
                  <button
                    className="secondary-btn"
                    onClick={() => respondToRequest(r.id, false)}
                  >
                    Decline
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <hr />

        {/* Add friend search */}
        <h4>Add Friend</h4>
        <input
          type="text"
          placeholder="Search by username..."
          value={searchText}
          onChange={(e) => searchUsers(e.target.value)}
          style={{ width: "100%", marginBottom: "10px" }}
        />

        {searchResults.length > 0 && (
          <div className="search-results">
            {searchResults.map((u) => (
              <div key={u.id} className="purchase-row">
                <span>{u.username}</span>
                <button
                  className="primary-btn"
                  onClick={() => sendFriendRequest(u.id)}
                >
                  Add Friend
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    )}
  </div>


        </div>
      </div>
    </div>
  );
}




// ---------------- ROOT APP ----------------
function App() {
  const [user, setUser] = useState(null);
  const [currentPage, setCurrentPage] = useState("home");
  const [cart, setCart] = useState([]);
  const [walletAddress, setWalletAddress] = useState(null);
  const [walletBalance, setWalletBalance] = useState(null);
  const [storeCreditWei, setStoreCreditWei] = useState("0");


  const [libraryGames, setLibraryGames] = useState([]);      // games user owns
  const [purchaseHistory, setPurchaseHistory] = useState([]); // recent transactions

    // Whenever we have a wallet address, auto-fetch its CFLR balance from MetaMask
  // Whenever we have a wallet address, fetch CFLR *token* balance
  useEffect(() => {
  async function fetchBalance() {
    if (!walletAddress || !window.ethereum) return;

    try {
      console.log("Auto fetching native CFLR balance for:", walletAddress);

      const balanceHex = await window.ethereum.request({
        method: "eth_getBalance",
        params: [walletAddress, "latest"],
      });

      console.log("auto raw native CFLR balance hex:", balanceHex);

      const formatted = formatCflrFromHex(balanceHex) ?? "0.0000";
      console.log("auto formatted native CFLR:", formatted);

      setWalletBalance(formatted);
    } catch (err) {
      console.error("Auto fetch CFLR balance error:", err);
      setWalletBalance(null);
    }
  }

  fetchBalance();
}, [walletAddress]);



  const handleAuth = (userData) => {
    setUser(userData);
    if (userData.walletAddress) {
      setWalletAddress(userData.walletAddress);
    }
    loadLibrary(userData.userId);
    loadPurchaseHistory(userData.userId);
    loadStoreCredit(userData.userId);  // 👈

  };

  const handleSignOut = () => {
    setUser(null);
    setCart([]);
    setWalletAddress(null);
    setWalletBalance(null);
    setLibraryGames([]);
    setPurchaseHistory([]);
    setCurrentPage("home");
  };

  const goToPage = (page) => {
    if (!user && (page === "library" || page === "profile" || page === "cart")) {
      setCurrentPage("signin");
      return;
    }
    setCurrentPage(page);
  };

  const loadLibrary = async (userId) => {
  try {
    const res = await fetch(`http://localhost:4000/api/library/${userId}`);
    const data = await res.json();

    if (!res.ok) {
      console.error("Library fetch failed:", data);
      setLibraryGames([]);
      return;
    }

    if (!Array.isArray(data)) {
      console.error("Library data is not an array:", data);
      setLibraryGames([]);
      return;
    }

    setLibraryGames(data);
  } catch (e) {
    console.error("Failed to load library:", e);
    setLibraryGames([]);
  }
};


  const loadPurchaseHistory = async (userId) => {
    try {
      const res = await fetch(`http://localhost:4000/api/transactions/${userId}`);
      const data = await res.json();
      setPurchaseHistory(data || []);
    } catch (e) {
      console.error("Failed to load purchase history:", e);
    }
  };

  const loadStoreCredit = async (userId) => {
    try {
      const res = await fetch(`http://localhost:4000/api/store-credit/${userId}`);
      const data = await res.json();
      setStoreCreditWei(data.store_credit_wei || "0");
    } catch (e) {
      console.error("Failed to load store credit:", e);
    }
  };


  const handlePurchaseComplete = async () => {
    if (user) {
      await loadLibrary(user.userId);
      await loadPurchaseHistory(user.userId);
    }
    setCart([]);
    setCurrentPage("library");
  };

  const handleTradeInComplete = async () => {
    if (user) {
      await loadLibrary(user.userId);
      await loadPurchaseHistory(user.userId);
      await loadStoreCredit(user.userId);
    }
  };

  
  const handleRefund = async (tx) => {
  if (!user) return;
  if (!tx.token_id) {
    alert("No token id stored for this purchase.");
    return;
  }

  const confirmReturn = window.confirm(
    `Return "${tx.game_name || "this game"}" for a refund?\nThis will burn your license and send your payment back.`
  );
  if (!confirmReturn) return;

  try {
    if (!window.ethereum) {
      alert("MetaMask not detected.");
      return;
    }

    // Make sure MetaMask has an account connected
    const accounts = await window.ethereum.request({
      method: "eth_requestAccounts",
    });

    if (!accounts || accounts.length === 0) {
      alert("No MetaMask account connected. Please connect your wallet first.");
      return;
    }

    console.log("Refund signer address:", accounts[0]);

    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer   = provider.getSigner();

    const contract = new ethers.Contract(
      GAME_OWNERSHIP_ADDRESS,
      GAME_OWNERSHIP_ABI,
      signer
    );

    console.log("Calling refundToken on-chain with tokenId:", tx.token_id);

    const onchainTx = await contract.refundToken(tx.token_id);
    console.log("Refund tx sent:", onchainTx.hash);

    const receipt = await onchainTx.wait();
    console.log("Refund confirmed:", receipt);

    // Record refund in backend & remove from library
    await fetch("http://localhost:4000/api/refund", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId:     user.userId,
        gameId:     tx.game_id,
        tokenId:    tx.token_id,
        txHash:     onchainTx.hash,
        fromAddress: GAME_OWNERSHIP_ADDRESS,
        toAddress:   user.walletAddress || walletAddress,
      }),
    });

    alert("Refund complete.");

    // reload library & history
    await loadLibrary(user.userId);
    await loadPurchaseHistory(user.userId);
  } catch (err) {
    console.error("Refund failed:", err);
    alert(
      "Refund failed – see console for details. It might be outside the return window, already refunded, or a network issue."
    );
  }

};


  // Central MetaMask + backend linking
  const handleConnectWallet = async () => {
  if (!window.ethereum) {
    alert("MetaMask not found. Please install it in your browser.");
    return;
  }

  // 1) Check which chain we're actually on.
  const chainId = await window.ethereum.request({ method: "eth_chainId" });
  console.log("Connected chainId:", chainId); // Coston should be 0x10 (decimal 16)

  // 2) Get accounts
  const accounts = await window.ethereum.request({
    method: "eth_requestAccounts",
  });

  const addr = accounts[0];
  console.log("DApp wallet address:", addr);

  setWalletAddress(addr);

  // 3) Native balance
  try {
    const balanceHex = await window.ethereum.request({
      method: "eth_getBalance",
      params: [addr, "latest"],
    });

    console.log("raw native CFLR balance hex:", balanceHex);
    const formatted = formatCflrFromHex(balanceHex) ?? "0.0000";
    console.log("formatted native CFLR:", formatted);
    setWalletBalance(formatted);
  } catch (err) {
    console.error("Error fetching native CFLR balance:", err);
    setWalletBalance(null);
  }

  // Link wallet to backend if logged in
  if (user) {
    try {
      const res = await fetch("http://localhost:4000/api/link-wallet", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.userId,
          walletAddress: addr,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        console.error("Link wallet error:", data);
      } else {
        setUser((prev) => (prev ? { ...prev, walletAddress: addr } : prev));
      }
    } catch (err) {
      console.error("Network error linking wallet:", err);
    }
  }

  return addr;
};



  let content = null;
  if (currentPage === "home")
    content = (
      <Home
        walletAddress={walletAddress}
        walletBalance={walletBalance}   
        onConnectWallet={handleConnectWallet}
      />
    );
  if (currentPage === "signin")
    content = <SignIn onAuth={handleAuth} goToPage={goToPage} />;
  if (currentPage === "profile")
    content = (
      <Profile
        user={user}
        walletAddress={walletAddress}
        walletBalance={walletBalance}
        onConnectWallet={handleConnectWallet}
        purchaseHistory={purchaseHistory}
        onRefund={handleRefund}
        goToPage={goToPage}
      />
    );
  if (currentPage === "store")
    content = <Store user={user} cart={cart} setCart={setCart}  goToPage={goToPage} libraryGames={libraryGames} />;
  if (currentPage === "cart")
    content = <Cart cart={cart} setCart={setCart} goToPage={goToPage} />;
  if (currentPage === "checkout") content = <Checkout cart={cart} user={user} walletAddress={walletAddress} goToPage={goToPage} onPurchaseComplete={handlePurchaseComplete} storeCreditWei={storeCreditWei}   />;
  if (currentPage === "library") content = <Library user={user} libraryGames={libraryGames}/>;
  if (currentPage === "trade")
  content = <TradeIn user={user} libraryGames={libraryGames} onTradeInComplete={handleTradeInComplete}/>;
  if (currentPage === "publish")
  content = <Publish user={user} />;


  return (
    <div className="app-container">
      <NavBar
        user={user}
        cart={cart}
        currentPage={currentPage}
        goToPage={goToPage}
        onSignOut={handleSignOut}
      />
      {content}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
