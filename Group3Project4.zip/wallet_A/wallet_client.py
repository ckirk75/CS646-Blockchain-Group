import json, socket, time, os, hashlib
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding

#MINER_HOST = '127.0.0.1'
MINER_HOST = "192.168.1.67"

def canonical(obj): 
    return json.dumps(obj, separators=(',', ':'), sort_keys=True)

def load_private_key(pem_path="private_key.pem"):
    from cryptography.hazmat.backends import default_backend
    with open(pem_path, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None, backend=default_backend())

def pub_pem_from_priv(priv):
    return priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo).decode()

def addr_from_pub(pub_pem):
    return hashlib.sha256(pub_pem.encode()).hexdigest()

def sign_body(priv, body):
    sig = priv.sign(canonical(body).encode(), padding.PKCS1v15(), hashes.SHA256())
    return sig.hex()

def send_json(port, payload):
    with socket.create_connection((MINER_HOST, port), timeout=2) as s:
        s.sendall((json.dumps(payload) + "\n").encode())

def mk_gossip(subtype, data):
    mid = hashlib.sha256((canonical(data) + "|" + subtype).encode()).hexdigest()
    return {"type": "gossip", "subtype": subtype, "msg_id": mid, "timestamp": time.time(), "data": data}

if __name__ == "__main__":
    MINER_PORT = 12345  # pick the miner you want to send to
    priv = load_private_key("private_key.pem")
    pub_pem = pub_pem_from_priv(priv)
    my_addr = addr_from_pub(pub_pem)
    body = {
        "timestamp": int(time.time()),
        "inputs": [{"prev_txid": "<FILL_ME>", "prev_index": 0}],
        "outputs": [{"address": "<RECIPIENT_ADDR>", "value": 1000}]
    }
    txid = hashlib.sha256(canonical(body).encode()).hexdigest()
    sig  = sign_body(priv, body)
    tx = {"txid": txid, "body": body,
          "inputs": [{**body["inputs"][0], "pubkey": pub_pem, "signature": sig}]}

    #payload = mk_gossip("tx", tx)
    payload = {"type": "tx", "payload": tx}
    send_json(MINER_PORT, payload)
    print("Sent tx to miner:", MINER_PORT)
