# miner_comm.py
import json, socket

#default ip : 127.0.0.1


def mk_msg(typ, payload):
    return json.dumps({"type": typ, "payload": payload}, separators=(",", ":"), sort_keys=True).encode()

def send_to_peer(port: int, payload_bytes: bytes, host='192.168.1.67', timeout=3.0):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        s.connect((host, port))
        #s.sendall(payload_bytes)
        s.sendall(payload_bytes if payload_bytes.endswith(b"\n") else payload_bytes + b"\n")

        
