# block.py  (helper-only)
import os, json, hashlib
from typing import List, Dict, Any
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend

def canonical(obj) -> str:
    return json.dumps(obj, separators=(',', ':'), sort_keys=True)

def header_bytes_for_pow(h: dict) -> bytes:
    strip = {k: v for k, v in h.items() if k not in ("pow", "pow_hash")}
    return canonical(strip).encode()

#def compute_pow_hash(header: dict) -> str:
   # return hashlib.sha256(header_bytes_for_pow(header)).hexdigest()

import hashlib, json

CANON_POW_KEYS = ["height","timestamp","previousblock",
                  "merkle_root","miner","nonce","difficulty"]

def compute_pow_hash(hdr: dict) -> str:
    canon = {k: hdr[k] for k in CANON_POW_KEYS if k in hdr}
    s = json.dumps(canon, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(s).hexdigest()

def meets_difficulty(hex_hash: str, zeros: int) -> bool:
    return isinstance(hex_hash, str) and hex_hash.startswith("0"*int(zeros))
    
def merkle_root(txids: List[str]) -> str:
    if not txids:
        return hashlib.sha256(b'').hexdigest()
    layer = txids[:]
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            a = layer[i]
            b = layer[i] if i + 1 == len(layer) else layer[i + 1]
            nxt.append(hashlib.sha256((a + b).encode()).hexdigest())
        layer = nxt
    return layer[0]

def address_from_pub(pub_pem: str) -> str:
    return hashlib.sha256(pub_pem.encode()).hexdigest()

def verify_signature(pub_pem: str, data_bytes: bytes, sig_hex: str) -> bool:
    try:
        pub = serialization.load_pem_public_key(pub_pem.encode(), backend=default_backend())
        pub.verify(bytes.fromhex(sig_hex), data_bytes, padding.PKCS1v15(), hashes.SHA256())
        return True
    except Exception:
        return False

def list_block_files(dirpath: str) -> List[str]:
    if not os.path.isdir(dirpath): return []
    files = [f for f in os.listdir(dirpath) if f.endswith(".json")]
    files.sort()
    return files

def load_blocks(dirpath: str) -> List[Dict[str, Any]]:
    chain = []
    for fname in list_block_files(dirpath):
        path = os.path.join(dirpath, fname)
        try:
            with open(path, "r") as f:
                blk = json.load(f)
        except Exception:
            continue
        header = blk.get("header")
        body   = blk.get("body")
        if not isinstance(header, dict) or not isinstance(body, list): 
            continue
        if not isinstance(header.get("height"), int):
            continue
        chain.append(blk)
    # <<< Ensure canonical chain order >>>
    chain.sort(key=lambda b: b["header"]["height"])
    return chain


def build_utxos(blocks: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    utxos = {}
    blocks = sorted(blocks, key=lambda b: b["header"]["height"])  # <<< add this
    for b in blocks:
        for tx in b.get("body", []):
            if not isinstance(tx, dict) or "txid" not in tx or "body" not in tx:
                continue
            txid = tx["txid"]
            # consume first
            for inp in tx.get("inputs", []):
                utxos.pop(f"{inp['prev_txid']}:{inp['prev_index']}", None)
            # then produce
            for i, outp in enumerate(tx["body"].get("outputs", [])):
                utxos[f"{txid}:{i}"] = {"value": outp["value"], "address": outp["address"]}
    return utxos

def validate_transaction(tx: dict, utxos: Dict[str, Dict[str, Any]]) -> bool:
    if "txid" not in tx or "body" not in tx or "inputs" not in tx:
        return False
    body = tx["body"]
    if "inputs" not in body or "outputs" not in body:
        return False

    expected_txid = hashlib.sha256(canonical(body).encode()).hexdigest()
    if tx["txid"] != expected_txid:
        return False

    total_out = 0
    for o in body["outputs"]:
        if "value" not in o or "address" not in o:
            return False
        if not isinstance(o["value"], int) or o["value"] < 0:
            return False
        total_out += o["value"]

    body_bytes = canonical(body).encode()
    seen = set()
    total_in = 0
    for inp in tx["inputs"]:
        for k in ("prev_txid", "prev_index", "pubkey", "signature"):
            if k not in inp:
                return False
        key = f"{inp['prev_txid']}:{inp['prev_index']}"
        if key in seen:
            return False
        seen.add(key)

        utxo = utxos.get(key)
        if not utxo:
            return False
        if not verify_signature(inp["pubkey"], body_bytes, inp["signature"]):
            return False
        if address_from_pub(inp["pubkey"]) != utxo["address"]:
            return False
        total_in += utxo["value"]

    if total_out > total_in:
        return False
    return True

# Block.py (keep your original validate_transaction as-is; add this helper)
def validate_transaction_verbose(tx, utxos):
    # Structure
    if "txid" not in tx or "body" not in tx or "inputs" not in tx:
        print("[debug] structure: missing keys")
        return False
    body = tx["body"]
    if "inputs" not in body or "outputs" not in body:
        print("[debug] structure: missing body.inputs/outputs")
        return False

    # txid integrity
    expected_txid = hashlib.sha256(canonical(body).encode()).hexdigest()
    if tx["txid"] != expected_txid:
        print("[debug] txid mismatch")
        return False

    # outputs sane
    total_out = 0
    for o in body["outputs"]:
        if "value" not in o or "address" not in o:
            print("[debug] outputs: missing keys")
            return False
        if not isinstance(o["value"], int) or o["value"] < 0:
            print("[debug] outputs: value not int or negative")
            return False
        total_out += o["value"]

    # inputs
    body_bytes = canonical(body).encode()
    seen_inputs = set()
    total_in = 0
    for inp in tx["inputs"]:
        for k in ("prev_txid", "prev_index", "pubkey", "signature"):
            if k not in inp:
                print("[debug] inputs: missing key", k)
                return False

        key = f"{inp['prev_txid']}:{inp['prev_index']}"
        if key in seen_inputs:
            print("[debug] inputs: duplicate input", key)
            return False
        seen_inputs.add(key)

        utxo = utxos.get(key)
        if not utxo:
            print("[debug] UTXO not found for", key)
            print("[debug] miner UTXO size:", len(utxos))
            return False

        if not verify_signature(inp["pubkey"], body_bytes, inp["signature"]):
            print("[debug] signature verify failed for", key)
            return False

        if address_from_pub(inp["pubkey"]) != utxo["address"]:
            print("[debug] ownership mismatch for", key)
            return False

        total_in += utxo["value"]

    if total_out > total_in:
        print("[debug] overspend: out", total_out, "> in", total_in)
        return False

    return True
