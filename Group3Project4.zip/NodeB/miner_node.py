# miner_node.py
import os, json, time, socket, threading, hashlib
import os, json, time, hashlib, socket, threading, traceback
import hashlib, json, time, threading, os
stop_mining_evt = threading.Event()  # set when a competing block is accepted
from collections import defaultdict,deque

from typing import Dict, Any, Set, List, Tuple

from blockHelper import (
    canonical, load_blocks, build_utxos, merkle_root, address_from_pub, validate_transaction_verbose as validate_transaction
)
from blockHelper import compute_pow_hash, meets_difficulty



# If you split write/create into helpers, import them too.

CONFIG = json.load(open("config.json"))
#PORT = CONFIG["port"]
HOST = '192.168.1.67'
PORT = 12346
#HOST  = CONFIG["host"]              # e.g. 127.0.0.1
#PORT  = CONFIG["port"] 
PEERS = CONFIG.get("peers", []) 
#PEERS: List[int] = CONFIG.get("peers", [])
#PEER =  [12345, 12345] 
MINER_ADDRESS = CONFIG["miner_wallet"]
MINE = bool(CONFIG.get("mine", False))
DIFF_ZEROS = int(CONFIG.get("difficulty_zeros", 5))
#DIFF_ZEROS = 5  # whatever you chose
RETARGET_EVERY = int(CONFIG.get("retarget_every", 0))  # optional if you want to extend later

'''
ROOT = os.path.dirname(os.path.abspath(__file__))
BLOCK_DIR = os.path.join(ROOT, "Blocks")
MEMPOOL_DIR = os.path.join(ROOT, "PendingTransactions")      # optional, if you mirror to disk
PROCESSED_DIR = os.path.join(ROOT, "ProcessedTransactions")  # optional
ROOT = os.path.dirname(os.path.abspath(__file__))

PENDING_DIR         = os.path.join(ROOT, "PendingTransactions")        
ACCEPTED_TX_DIR     = os.path.join(ROOT, "AcceptedTransactions")       
ACCEPTED_BLOCKS_DIR = os.path.join(ROOT, "AcceptedBlocks")


os.makedirs(BLOCK_DIR, exist_ok=True)
os.makedirs(MEMPOOL_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)
'''
ROOT = os.path.dirname(os.path.abspath(__file__))
SHARED = os.path.abspath(os.path.join(ROOT, ".."))   
ADDRESSES = os.path.join(SHARED, "addresses.json")
ACCEPTED_BLOCKS_DIR = os.path.join(ROOT, "AcceptedBlocks")
ACCEPTED_TX_DIR     = os.path.join(ROOT, "AcceptedTransactions")
PENDING_DIR         = os.path.join(ROOT, "PendingTransactions")  # optional mirror
os.makedirs(ACCEPTED_BLOCKS_DIR, exist_ok=True)
os.makedirs(ACCEPTED_TX_DIR, exist_ok=True)
os.makedirs(PENDING_DIR, exist_ok=True)

BLOCK_DIR = "AcceptedBlocks"
TX_DIR    = "AcceptedTransactions"
LOG_FILE  = "communicationLog.txt"



os.makedirs(BLOCK_DIR, exist_ok=True)
os.makedirs(TX_DIR, exist_ok=True)

#default ip : 127.0.0.1
#my testing ip:  192.168.1.67
#uab ip: 172.24.76.70

# Node state
'''
seen_msgs: Set[str] = set()           # dedup for gossip
mempool: Dict[str, dict] = {}         # txid -> tx
lock = threading.Lock()
'''

mp_lock = threading.Lock()
mempool = {}
COINBASE_REWARD = 50_000
block_by_hash: dict[str, dict] = {}
children: dict[str, list[str]] = defaultdict(list)
height_of: dict[str, int] = {}
active_tip_hash: str | None = None
active_utxos: dict[str, dict] = {}
orphan_blocks: dict[str, list[dict]] = defaultdict(list)  # parent_hdr_hash -> [child blocks...]


def index_block(blk: dict):
    h = file_hash_of_header(blk["header"])
    p = blk["header"].get("previousblock", "NA")
    block_by_hash[h] = blk
    height_of[h] = blk["header"]["height"]
    if p != "NA":
        children[p].append(h)


def compute_best_tip() -> str | None:
    if not height_of:
        return None
    return max(height_of, key=lambda hh: height_of[hh])


def log(line: str):
    with open(LOG_FILE, "a") as f:
        f.write(time.strftime("[%H:%M:%S] ") + line + "\n")

def sha256_hex(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()

def header_pow_bytes(header: dict) -> bytes:
    """Bytes used for the PoW hash. Include *all* header fields (incl. nonce)."""
    # IMPORTANT: we hash the canonicalized header (which includes 'nonce')
    return json.dumps(header, separators=(",", ":"), sort_keys=True).encode()

#def meets_difficulty(hex_hash: str, zeros: int) -> bool:
 #   return hex_hash.startswith("0" * zeros)

# At top-level of miner_node.py
def ensure_pow_fields(bdict):
    is_block = 'header' in bdict
    hdr = bdict['header'] if is_block else bdict
    hdr['difficulty'] = int(hdr.get('difficulty', DIFF_ZEROS))  # single source
    hdr['pow_hash'] = compute_pow_hash(hdr)
    if is_block:
        bdict['header'] = hdr
        return bdict
    return hdr

'''
def validate_pow(hdr: dict) -> bool:
    hdr = ensure_pow_fields(hdr)
    powh = compute_pow_hash(hdr)
    return meets_difficulty(powh, int(hdr.get('difficulty', DIFF_ZEROS)))
'''
'''
def validate_pow(hdr: dict) -> bool:
    # Normalize first (adds difficulty, recomputes pow_hash using canonical hash)
    hdr = ensure_pow_fields(hdr)

    if 'nBits' in hdr:
        target = nbits_to_target(hdr['nBits'])
    elif 'target' in hdr:
        target = int(hdr['target'], 16)
    else:
        target = difficulty_to_target(int(hdr.get('difficulty', DIFF_ZEROS)))

    pow_hash = compute_pow_hash(hdr)
    return int(pow_hash, 16) <= target
'''

def validate_pow(hdr: dict) -> bool:
    # recompute pow hash over canonical fields (ignore any provided pow_hash)
    pow_hash = compute_pow_hash(hdr)
    zeros = int(hdr.get("difficulty", DIFF_ZEROS))
    return meets_difficulty(pow_hash, zeros)





#orphan_blocks = {}
#orphan_blocks: dict[str, list[dict]] = {}  # key = parent_header_hash -> [child_blocks...]



def mk_msg(subtype: str, data: dict) -> dict:
    mid = sha256_hex((canonical(data) + "|" + subtype).encode())
    return {"type":"gossip","subtype":subtype,"msg_id":mid,"timestamp":time.time(),"data":data}



def send_to_peer(addr: str, port: int, payload: dict, retries: int = 2):
    data = json.dumps(payload).encode()
    for attempt in range(retries + 1):
        try:
            with socket.create_connection((addr, port), timeout=0.6) as s:  # short connect timeout
                s.settimeout(1.5)  # read/write timeout
                s.sendall(data + b"\n")
            return True
        except (socket.timeout, ConnectionRefusedError, OSError) as e:
            if attempt < retries:
                time.sleep(0.15)
                continue
            print(f"[gossip] failed to {addr}:{port} -> {e.__class__.__name__}")
            return False

def gossip_to_peers(payload: dict, exclude: tuple[str,int] | None = None):
    for peer in PEERS:                       # PEERS: [{"host": "...", "port": 12346}, ...]
        tgt = (peer["host"], peer["port"])
        if exclude and tgt == exclude:
            continue
        send_to_peer(peer["host"], peer["port"], payload, 2)


def save_tx_locally(tx: dict):
    fname = os.path.join(TX_DIR, f"{tx['txid']}.json")
    if not os.path.exists(fname):
        with open(fname, "w") as f: json.dump(tx, f, indent=2)

def save_block_locally(block_obj: dict) -> str:
    header = block_obj["header"]
    fname = sha256_hex(canonical(header).encode()) + ".json"
    path = os.path.join(BLOCK_DIR, fname)
    with open(path, "w") as f: json.dump(block_obj, f, indent=2)
    return path

def validate_coinbase_rules(block_obj: dict, expected_reward: int) -> bool:
    body = block_obj.get("body")
    header = block_obj.get("header", {})
    if not isinstance(body, list) or len(body) == 0:
        return False

    # 1) coinbase must be FIRST
    cb = body[0]
    if not isinstance(cb, dict) or not cb.get("body") or not cb["body"].get("coinbase", False):
        return False

    # 2) coinbase must have NO inputs
    if cb.get("inputs"):
        return False
    if cb["body"].get("inputs"):  # if present redundantly in body
        return False

    # 3) coinbase outputs must be exactly one output to header.miner
    outs = cb["body"].get("outputs")
    if not isinstance(outs, list) or len(outs) != 1:
        return False

    out0 = outs[0]
    if "address" not in out0 or "value" not in out0:
        return False

    miner_in_header = header.get("miner")
    if not isinstance(miner_in_header, str) or len(miner_in_header) < 40:
        # if you *don’t* want miner in header, remove this and relax the check
        return False

    # 4) To field should be miner address
    if out0["address"] != miner_in_header:
        return False

    # 5) Amount is fixed standard reward
    if out0["value"] != expected_reward:
        return False

    # 6) No other coinbase later in the block
    for t in body[1:]:
        if isinstance(t, dict) and t.get("body", {}).get("coinbase", False):
            return False

    return True


TARGET_BLOCK_TIME = 120 # 2 minutes
#RETARGET_EVERY = int(CONFIG.get("retarget_every", 10))


def maybe_retarget(new_tip_hash: str):
    if RETARGET_EVERY <= 0:
        return
    tip_h = height_of.get(new_tip_hash, 0)
    if tip_h % RETARGET_EVERY != 0 or tip_h < RETARGET_EVERY:
        return
    path = chain_path_to(new_tip_hash)
    window = [block_by_hash[h]["header"]["timestamp"] for h in path[-RETARGET_EVERY:]]
    actual = (max(window) - min(window)) / max(1, (RETARGET_EVERY - 1))
    global DIFF_ZEROS
    if actual < TARGET_BLOCK_TIME * 0.7 and DIFF_ZEROS < 8:
        DIFF_ZEROS += 1
    elif actual > TARGET_BLOCK_TIME * 1.5 and DIFF_ZEROS > 1:
        DIFF_ZEROS -= 1
    print(f"[retarget] avg={actual:.1f}s → difficulty zeros={DIFF_ZEROS}")

def server_loop():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    #srv.bind((HOST, PORT))
    #srv.bind(('', 12345))
    srv.bind(('192.168.1.133', 12345))
    srv.listen(16)
    # Accept a connection from a client
    #client_socket, 
    #client_address = srv.accept()
    #print(f"Connection from {client_address} has been established.")
    log(f"listening on {PORT}")

    
    while True:
        conn, addr = srv.accept()
        threading.Thread(target=handle_conn, args=(conn,), daemon=True).start()
        '''
        with socketserver.ThreadingTCPServer((HOST, PORT), Handler) as srv:
            try:
                srv.serve_forever()
            except KeyboardInterrupt:
                print("\n[!] Caught Ctrl+C, ending connection.")
                break
            finally:
                srv.server_close()
                '''


        



def start_server(host: str, port: int):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((host,port))
    srv.listen(16)
    print(f"[miner] listening on {host}:{port}")

    while True:
        conn, addr = srv.accept()
        threading.Thread(target=handle_conn, args=(conn, addr), daemon=True).start()

def handle_conn(conn: socket.socket, addr):
    # addr = (ip, port) of the TCP *client socket* arriving here
    origin = addr  # tuple[str,int]
    try:
        f = conn.makefile("rb")
        for line in f:
            if not line:
                break
            handle_message(line.decode("utf-8", errors="replace"), origin_port=origin)
    finally:
        try: conn.close()
        except: pass


def handle_message(raw: str, origin_port: int | None):
    try:
        msg = json.loads(raw)
        typ = msg.get("type")
        if typ == "tx":
            handle_tx(msg, origin_port)
        elif typ == "block":
            handle_block(msg, origin_port)
        # in miner_node.py handle_message(...)
        elif typ == "get_utxos":
            addr = msg.get("address")
            chain = load_blocks(ACCEPTED_BLOCKS_DIR)
            utxos = build_utxos(chain)
            # filter for this address
            out = {k:v for k,v in utxos.items() if v["address"] == addr}
            # reply back on the same socket: include "correlation_id" if you want
            reply = {"type":"utxos", "address": addr, "utxos": out}
            conn = msg.get("_reply_conn")  # or pass the socket down into handle_message
        elif typ == "get_block":
            want = msg.get("hash")
            if isinstance(want, str):
                for fname in os.listdir(ACCEPTED_BLOCKS_DIR):
                    if not fname.endswith(".json"): continue
                    blk = json.load(open(os.path.join(ACCEPTED_BLOCKS_DIR, fname)))
                    if file_hash_of_header(blk["header"]) == want:
                        # reply only to the requester
                        if origin_port:
                            send_to_peer(origin_port[0], origin_port[1], {"type":"block","payload": blk})
                        break
        elif typ == "get_tip":
            if active_tip_hash:
                reply = {"type":"tip","hash": active_tip_hash, "height": height_of.get(active_tip_hash, 0)}
                if origin_port:
                    send_to_peer(origin_port[0], origin_port[1], reply)
        elif typ == "tip":
            peer_tip = msg.get("hash")
            peer_h   = int(msg.get("height", -1))
            my_h     = height_of.get(active_tip_hash, -1) if active_tip_hash else -1
            if peer_tip and peer_h > my_h:
                # naive linear sync: walk back by requesting that hash; your get_block replays handle_block
                send_to_peer(origin_port[0], origin_port[1], {"type":"get_block","hash": peer_tip})



        else:
            # ignore unknown
            pass
    except Exception:
        print("[handle_message] exception:")
        traceback.print_exc()

def handle_receiving(client_socket):
    while True:
        try:
            data = client_socket.recv(4096)
            if not data:
                print("User B disconnected.")
                break
            try:
                '''
                decrypted = decrypt_message(data, selected_mode)
                # Check if the other side wants to end
                if decrypted.lower() in ("end chat", "quit chat"):
                    print("The other user ended the chat.")
                    break

                '''
                miner_loop()
                print(f"User B: {decrypted}")
            except Exception as e:
                print(f" Decryption failed: {e}")
                break
        except:
            break
    # Once we exit the loop, close the socket
    client_socket.close()
    print("[!] handle_receiving thread ended.")

# top-level
seen_txs: set[str] = set()
seen_blocks: set[str] = set()





def handle_tx(msg, origin_port):
    tx = msg.get("payload")
    if not isinstance(tx, dict):
        return
    txid = tx.get("txid")
    if not txid:
        return


    # hard dedupe early
    if txid in seen_txs:
        return
    seen_txs.add(txid)


    # Reject coinbase from users
    if tx.get("body", {}).get("coinbase", False):
        print("[miner] reject tx: users cannot submit coinbase")
        return


    # Validate vs current best chain
    utxo_snapshot = active_utxos.copy()
    if not validate_transaction(tx, utxo_snapshot):
        print(f"[miner] reject tx {txid} (invalid)")
        return


    with mp_lock:
        if txid in mempool:
            return
        mempool[txid] = tx


    # Persist optional pending copy
    try:
        with open(os.path.join(PENDING_DIR, f"{txid}.json"), "w") as f:
            json.dump(tx, f, indent=2)
    except Exception:
        pass


    # Gossip to peers
    payload = {"type": "tx", "payload": tx}
    gossip_to_peers(payload, exclude=origin_port)
    print(f"[miner] accepted tx {txid} (mempool size: {len(mempool)})")


# at top-level (once):

def header_hash(hdr: dict) -> str:
    return hashlib.sha256(
        json.dumps(hdr, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()

def handle_block(msg: dict, origin_port: tuple[str,int] | None):
    blk = msg.get("payload")
    if not isinstance(blk, dict):
        return

    header = blk.get("header", {})
    body   = blk.get("body", [])
    if not isinstance(header, dict) or not isinstance(body, list):
        return

    # miner_node.py (start of handle_block)
    new_hash = file_hash_of_header(header)
    if new_hash in seen_blocks:
        return
    seen_blocks.add(new_hash)


    # (A) coinbase rules
    if not validate_coinbase_rules(blk, COINBASE_REWARD):
        print("[miner] reject block: coinbase invalid")
        return

    # (B) merkle
    txids = [t["txid"] for t in body if "txid" in t]
    mr = merkle_root(txids)
    if mr != header.get("merkle_root"):
        print("[miner] reject block: merkle mismatch")
        return

    # (C) height & linkage
    # (C) Parent presence & height
    parent_hash = header.get("previousblock")
    if parent_hash != "NA" and not os.path.exists(os.path.join(ACCEPTED_BLOCKS_DIR, parent_hash + ".json")):
        orphan_blocks[parent_hash].append(blk)
        #gossip_to_peers({"type":"get_block","hash": parent_hash}, exclude=origin_port)
        if origin_port:
            send_to_peer(origin_port[0], origin_port[1], {"type":"get_block","hash": parent_hash})
        return


    if parent_hash == "NA":
        expected_parent_height = -1
    else:
        parent_blk = json.load(open(os.path.join(ACCEPTED_BLOCKS_DIR, parent_hash + ".json")))
        expected_parent_height = parent_blk["header"]["height"]


    if header.get("height") != expected_parent_height + 1:
        print("[miner] reject block: wrong height relative to parent")
        return


    # (D) PoW validation (normalize once), same policy
    after_norm = ensure_pow_fields(blk)
    header = after_norm["header"]
    if not validate_pow(header):
        print("[miner] reject block: bad PoW")
        return


    # (E) Validate txs against parent context
    parent_utxos = rebuild_active_utxo(parent_hash) if parent_hash != "NA" else {}
    # Apply coinbase first
    cb = body[0]
    cb_txid = cb["txid"]
    for i, outp in enumerate(cb["body"]["outputs"]):
        parent_utxos[f"{cb_txid}:{i}"] = {"value": outp["value"], "address": outp["address"]}
    # Then normals
    for tx in body[1:]:
        if not validate_transaction(tx, parent_utxos):
            print("[miner] reject block: contains invalid tx", tx.get("txid"))
            return
        for inp in tx.get("inputs", []):
            parent_utxos.pop(f"{inp['prev_txid']}:{inp['prev_index']}", None)
        tid = tx["txid"]
        for i, outp in enumerate(tx["body"]["outputs"]):
            parent_utxos[f"{tid}:{i}"] = {"value": outp["value"], "address": outp["address"]}


    # (F) Persist + index (idempotent)
    new_hash = file_hash_of_header(header)
    fname = new_hash + ".json"
    path = os.path.join(ACCEPTED_BLOCKS_DIR, fname)
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump(after_norm, f, indent=2)
        index_block(after_norm)
        recompute_active_view(new_hash)
        revalidate_mempool()
        stop_mining_evt.set()
        maybe_retarget(new_hash)
        stop_mining_evt.set()



    # (G) Longest‑chain selection / reorg
    cur_best_h = height_of.get(active_tip_hash, -1) if active_tip_hash else -1
    cand_h = height_of[new_hash]
    if cand_h > cur_best_h:
        recompute_active_view(new_hash)
        revalidate_mempool()
        stop_mining_evt.set()
        stop_mining_evt.set()
        gossip_to_peers({"type": "block", "payload": after_norm}, exclude=origin_port)
    else:
    # side branch kept, no reorg
        pass

        # (H) Mempool pruning (remove included)
    included = {t["txid"] for t in body if "txid" in t}
    with mp_lock:
        for txid in list(included):
            if txid in mempool:
                try:
                    with open(os.path.join(ACCEPTED_TX_DIR, f"{txid}.json"), "w") as f:
                        json.dump(mempool[txid], f, indent=2)
                except Exception:
                    pass
                mempool.pop(txid, None)
            try:
                os.remove(os.path.join(PENDING_DIR, f"{txid}.json"))
            except FileNotFoundError:
                pass


    # (I) Drain orphan queue for this parent
    this_hash = new_hash
    q = deque(orphan_blocks.pop(this_hash, []))
    while q:
        child = q.pop()
        handle_block({"payload": child}, origin_port=None)
        chh = file_hash_of_header(child.get("header", {}))
        q.extend(orphan_blocks.pop(chh, []))

        # stop current mining attempt (if we were mining)
        #stop_mining_evt.set()

    # gossip onward
    #payload = {"type": "block", "payload": blk}
    #gossip_to_peers(payload, exclude=origin_port)




def file_hash_of_header(header: dict) -> str:
    body = json.dumps(header, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(body).hexdigest()

def chain_path_to(tip_hash: str) -> list[str]:
    path = []
    cur = tip_hash
    while True:
        blk = block_by_hash.get(cur)
        if not blk:
            break
        path.append(cur)
        prev = blk["header"].get("previousblock", "NA")
        if prev == "NA":
            break
        cur = prev
    path.reverse()
    return path


def rebuild_active_utxo(best_tip_hash: str) -> dict:
    utxos: dict[str, dict] = {}

    for hh in chain_path_to(best_tip_hash):
        blk = block_by_hash[hh]
        txs = blk.get("body", [])

        # ensure coinbase is applied first
        txs_sorted = sorted(
            txs,
            key=lambda t: 0 if t.get("body", {}).get("coinbase", False) else 1
        )

        for tx in txs_sorted:
            body = tx.get("body", {})
            txid = tx.get("txid")

            # 1) consume inputs (skip for coinbase)
            if not body.get("coinbase", False):
                for inp in tx.get("inputs", []):
                    utxos.pop(f"{inp['prev_txid']}:{inp['prev_index']}", None)

            # 2) produce outputs (for *all* txs, incl. coinbase)
            for idx, outp in enumerate(body.get("outputs", [])):
                utxos[f"{txid}:{idx}"] = {
                    "value": outp["value"],
                    "address": outp["address"]
                }

    return utxos



# miner_node.py
def recompute_active_view(new_tip_hash: str):
    global active_tip_hash, active_utxos
    active_utxos = rebuild_active_utxo(new_tip_hash)
    active_tip_hash = new_tip_hash
    stop_mining_evt.clear()  # <-- make next mining attempt clean



# miner_node.py
def revalidate_mempool():
    global mempool
    with mp_lock:
        utxo_view = active_utxos.copy()
        keep = {}
        for txid, tx in mempool.items():
            if validate_transaction(tx, utxo_view):
                # apply effects so later txs see updated state
                for inp in tx.get("inputs", []):
                    utxo_view.pop(f"{inp['prev_txid']}:{inp['prev_index']}", None)
                tid = tx["txid"]
                for i, outp in enumerate(tx["body"]["outputs"]):
                    utxo_view[f"{tid}:{i}"] = {"value": outp["value"], "address": outp["address"]}
                keep[txid] = tx
        mempool = keep


def coinbase_tx(to_addr: str, reward: int) -> dict:
    body = {
        "timestamp": int(time.time()),
        "inputs": [],                            # <-- must be empty
        "outputs": [{"address": to_addr, "value": reward}],
        "coinbase": True                         # <-- explicit marker
    }
    return {
        "txid": hashlib.sha256(json.dumps(body, separators=(",", ":"), sort_keys=True).encode()).hexdigest(),
        "body": body,
        "inputs": []                              # mirrors body.inputs
    }

# miner_node.py
def ensure_genesis(block_dir: str, recipients: list[dict]):
    # Only write if no valid block exists
    for f in os.listdir(block_dir):
        if not f.endswith(".json"): 
            continue
        try:
            blk = json.load(open(os.path.join(block_dir, f)))
            if isinstance(blk.get("header"), dict) and isinstance(blk.get("body"), list):
                return
        except: 
            pass

    GEN_TS = 1700000000  # <-- fixed timestamp!
    # IMPORTANT: recipients order must be stable (A, B, C)
    coinbase_body = {
        "timestamp": GEN_TS,
        "inputs": [],
        "outputs": recipients,
        "coinbase": True
    }
    cb_tx = {
        "txid": hashlib.sha256(canonical(coinbase_body).encode()).hexdigest(),
        "body": coinbase_body,
        "inputs": []
    }
    header = {
        "height": 0,
        "timestamp": GEN_TS,
        "previousblock": "NA",
        "merkle_root": merkle_root([cb_tx["txid"]]),
        "hash": hashlib.sha256(canonical([cb_tx]).encode()).hexdigest()
    }
    block = {"header": header, "body": [cb_tx]}
    fname = hashlib.sha256(canonical(header).encode()).hexdigest() + ".json"
    with open(os.path.join(block_dir, fname), "w") as f:
        json.dump(block, f, indent=2)
    print(f"[genesis] wrote {fname} with {len(recipients)} outputs")



def debug_dump_utxos_once():
    chain = load_blocks(ACCEPTED_BLOCKS_DIR)
    utxos = build_utxos(chain)
    print("[debug] miner UTXOs:", list(utxos.keys()))



def mine_once():
    chain = load_blocks(ACCEPTED_BLOCKS_DIR)
    last  = max(chain, key=lambda b: b["header"]["height"], default=None)
    height = 0 if last is None else last["header"]["height"] + 1
    prev_hash = "NA" if last is None else file_hash_of_header(last["header"])

    # snapshot mempool to avoid mutation during mining
    with mp_lock:
        txs_snapshot = list(mempool.values())
    if not txs_snapshot:
        return

    # Filter mempool against current active_utxos
    utxo_view = active_utxos.copy()
    valids = []
    for tx in txs_snapshot:
        if validate_transaction(tx, utxo_view):
            # apply to utxo_view so later txs see updated state
            for inp in tx.get("inputs", []):
                utxo_view.pop(f"{inp['prev_txid']}:{inp['prev_index']}", None)
            tid = tx["txid"]
            for i, outp in enumerate(tx["body"]["outputs"]):
                utxo_view[f"{tid}:{i}"] = {"value": outp["value"], "address": outp["address"]}
            # append once per validated tx
            valids.append(tx)

    cb = coinbase_tx(MINER_ADDRESS, COINBASE_REWARD)
    body = [cb] + valids
    txids = [t["txid"] for t in body if "txid" in t]

    header = {
        "height": height,
        "timestamp": int(time.time()),
        "previousblock": prev_hash,
        "merkle_root": merkle_root(txids),
        "miner": MINER_ADDRESS,
        "nonce": 0,            # will change inside the loop
        "difficulty": DIFF_ZEROS,   # <-- include difficulty in header
        # DO NOT include "pow_hash" yet
    }

    # ---- PoW loop ----
        # PoW loop
    # ---- PoW loop ----
    # before starting PoW
    stop_mining_evt.clear()

    # ---- PoW loop ----
    nonce = 0
    while True:
        # NEW: abort if a competing block was accepted
        if stop_mining_evt.is_set():
            return  # abandon this attempt

        header["nonce"] = nonce
        h = compute_pow_hash(header)
        if meets_difficulty(h, DIFF_ZEROS):
            header["pow_hash"] = h
            break
        nonce += 1



    # (optional) single assert using same policy
    if not validate_pow(header):
        print("[miner] reject block: bad PoW"); return

    block = {"header": header, "body": body}   # ← you were missing this line later



    # Now it's safe to print pow_hash
    print(f"[miner] mined block {file_hash_of_header(header)}.json "
          f"with {len(txs_snapshot)} txs + coinbase @nonce={header['nonce']} "
          f"pow={header['pow_hash'][:16]}…")

    # Persist block
    fname = file_hash_of_header(header) + ".json"
    with open(os.path.join(ACCEPTED_BLOCKS_DIR, fname), "w") as f:
        json.dump(block, f, indent=2)
    print(f"[miner] mined block {fname} with {len(txs_snapshot)} txs + coinbase @nonce={header['nonce']} pow={header['pow_hash'][:16]}…")

    # Remove included txs from mempool + move to AcceptedTransactions
    included = {t["txid"] for t in txs_snapshot}
    with mp_lock:
        for txid in included:
            if txid in mempool:
                try:
                    with open(os.path.join(ACCEPTED_TX_DIR, f"{txid}.json"), "w") as f:
                        json.dump(mempool[txid], f, indent=2)
                except Exception:
                    pass
                mempool.pop(txid, None)
            try:
                os.remove(os.path.join(PENDING_DIR, f"{txid}.json"))
            except FileNotFoundError:
                pass

    # Gossip the new block
    payload = {"type": "block", "payload": block}
    gossip_to_peers(payload)





def miner_loop():
    REWARD = 50_000
    while True:
        try:
            mine_once()
        except Exception:
            print("[miner_loop] exception while mining:")
            traceback.print_exc()
        time.sleep(5)
'''
def miner_loop():
    REWARD = 50_000  # example reward
    INTERVAL_SEC = 5 # e.g., mine every 5s if you have txs
    while True:
        time.sleep(INTERVAL_SEC)
        # snapshot mempool
        with lock:
            txs = list(mempool.values())
        if not txs:
            continue

        # Make a block: coinbase + some (or all) txs
        chain = load_blocks(BLOCK_DIR)
        txids = [t["txid"] for t in txs]
        # Assemble block header/body quickly (you can call your create_block)
        body = []

        # coinbase (first)
        coinbase = {
            "txid": hashlib.sha256(b"coinbase"+str(time.time()).encode()).hexdigest(),
            "body": {"timestamp": int(time.time()), "inputs": [], "outputs": [{"address": MINER_ADDRESS, "value": REWARD}], "coinbase": True},
            "inputs": []
        }
        body.append(coinbase)
        body.extend(txs)

        # Header
        last = None
        if chain:
            # highest height
            last = max(chain, key=lambda b: b["header"]["height"])
            prev_hash = hashlib.sha256(canonical(last["header"]).encode()).hexdigest()
            height = last["header"]["height"] + 1
        else:
            prev_hash = "NA"
            height = 0

        block_hash_body = hashlib.sha256(canonical(body).encode()).hexdigest()
        header = {
            "height": height,
            "timestamp": int(time.time()),
            "previousblock": prev_hash,
            "merkle_root": merkle_root([tx["txid"] for tx in body]),
            "hash": block_hash_body
        }
        block_obj = {"header": header, "body": body}

        # Save locally, clear mempool, gossip block
        path = save_block_locally(block_obj)
        log(f"MINED {path}")

        with lock:
            for t in txids:
                mempool.pop(t, None)

        gossip_to_peers(mk_msg("block", block_obj))

        '''
        



''' 
if __name__ == "__main__":
    threading.Thread(target=server_loop, daemon=True).start()
    server_loop()
    miner_loop()  # foreground loop
'''

'''
client_socket = srv.accept()
recv_thread = threading.Thread(target=handle_block, args=(client_socket,), daemon=True)
send_thread = threading.Thread(target=handle_message, args=(client_socket,), daemon=True)
recv_thread.start()
send_thread.start()

recv_thread.join()
send_thread.join()
#server_loop()
miner_loop()
'''
#srv.accept()

if __name__ == "__main__":

    # load A/B/C addresses from your shared addresses.json
    addr_book = json.load(open(os.path.join(ROOT,SHARED, "addresses.json")))
    recipients = [
        {"address": addr_book["A"]["address"], "value": 1_000_000},
        {"address": addr_book["B"]["address"], "value": 1_000_000},
        {"address": addr_book["C"]["address"], "value": 1_000_000},
    ]
    ensure_genesis(ACCEPTED_BLOCKS_DIR, recipients)
    # Build in‑memory index from disk, set best tip, compute active UTXO
    for fname in os.listdir(ACCEPTED_BLOCKS_DIR):
        if not fname.endswith(".json"):
            continue
        blk = json.load(open(os.path.join(ACCEPTED_BLOCKS_DIR, fname)))
        if isinstance(blk.get("header"), dict) and isinstance(blk.get("body"), list):
            index_block(blk)


    active_tip_hash = compute_best_tip()
    if active_tip_hash is None:
        # pick the genesis by height==0
        for h, blk in block_by_hash.items():
            if blk["header"].get("height") == 0:
                active_tip_hash = h
                break
    recompute_active_view(active_tip_hash)

    debug_dump_utxos_once()

    # server thread
    threading.Thread(target=start_server, args=('192.168.1.67', 12346), daemon=True).start()
    #threading.Thread(target=start_server, args=(HOST, PORT), daemon=True).start()

    # mining thread
    #threading.Thread(target=miner_loop, daemon=True).start()
    # only primary miner runs the mining loop
    if MINE:
        threading.Thread(target=miner_loop, daemon=True).start()



    print("[miner] running. Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[miner] shutting down")



