# CS646-Blockchain-Group
# Requirements:
 1. python 3.8
 # How to run the project:
# step 0:run genesis_block.py
It seeds wallets with a starting balance with a starting block 
 # step 1: for nodeA, nodeB and nodeC folders run python for miner_node.py for those 3 in separate terminals and have them running in the background may have to change the miner_host ip 
in the config we have miner host ips set to a default ip
#step 2: in another separate terminal go into nodeA, nodeB, or NodeC and run python transaction.py
 It prompts the user to enter
 Sender:
 Sender wallet (A/B/C):
 Receiver:
 Receiver wallet (A/B/C or paste address):
 Amount:
 After this a new file will be created as a transaction request inside the tx_requests folder.
 # step 3:  in walletA, walletB, or walletC run python wallet.py
In this step all transactions requests in tx_requests will get processed, the drafts transactions will be signed and created, they will send signed transactions to a Miner over the ports using socket communication.
then using the gossip protocol the listening miner nodes will receive transactions from Wallets
each time we run wallet.py file, will create new transaction files, new transaction files are signed, and transaction are validated, verified valid miner nodes will receive transactions from Wallets will validate transaction details for correct format, all required information present, valid signature, and sufficient balances 
after miner node creates a block with transactions and keeps a local copy of the blockchain using the help of our block python file and throught our gossip protocol, it will send a copy of the latest block to other miners when complete
POW puzzle is  is ran

# step 4: in walletA, walletB, or walletC run python wallet_client.py
In this step the wallet_client send a update log to the communicationlog.txt
